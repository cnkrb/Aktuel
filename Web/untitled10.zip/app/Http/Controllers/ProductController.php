<?php

namespace App\Http\Controllers;

use App\Product;
use App\Store;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=Product::all();
        return  view('');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {



        if ($request->hasFile('patch')) {


            $request->validate([
                'patch' => 'image|mimes:jpg,png|max:2048'
            ]);
            $filename = uniqid() . '.' . $request->patch->getClientOriginalExtension();
            $request->patch->move(public_path('public/images/products'), $filename);


            $int = (int)+$request->storeId;

            $store=Product::create([
                'storeId' => $int,
                'patch' => $filename,
                'date' => $request->date,

            ]);

            if($store){

                return redirect(route('product.edit',$int))->with('success', 'İşlem Başarılı');
            }
        }
        else
        { echo $request->storeId;}
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data['store']=Store::where('id',$id)->first();
        $data['product']=Product::where('storeId',$id)->get();

        return  view('addProduct',compact('data',$data));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {

        $store = Product::find(intval($id));
        echo $store->patch;
        if ($store->delete()) {
            $path = '/public/images/products/' . $store->patch;
            if (file_exists($path)) {
                @unlink(public_path($path));
            }
            echo 1;
        }
        echo 0;

    }

    public function  getProduct($id){
        $data=Product::where('storeId',$id)->get();
        return response()->json($data);
    }
}
